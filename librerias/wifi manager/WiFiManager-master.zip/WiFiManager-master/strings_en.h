/**
 * Contents of this file have moved to 2 new locations
 * wm_strings_nn.h
 *  wm_consts_nn.h
 */

#warning "This file is deprecated"

#ifndef _STRINGS_EN_H_
#define _STRINGS_EN_H_

// strings files must include a consts file!
#include "wm_strings_en.h" // include constants, tokens, routes

#endif